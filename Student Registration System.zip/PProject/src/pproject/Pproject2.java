package pproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTable;
import javax.swing.border.LineBorder;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.SwingUtilities;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.Image;
import javax.swing.JCheckBox;
import javax.swing.JToggleButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class Pproject2 {
	/**
	 * For Image Browse.
	 */
	
	private JFrame frame;
	private JTable table;
	private JTable table_1;
	private JTable table_2;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_9;
	private JTextField textField_22;
	private JTextField textField_24;
	private JTextField textField_26;
	private JTextField textField_28;
	private JTextField textField_30;
	private JTextField textField_32;
	private JTextField textField_33;
	private JTextField textField_34;
	private JTextField textField_35;
	private JTextField textField_36;
    private JComboBox comboBox;
	/**
	 * Launch the application.
	 */
	public static void AdmForm() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");//Loading Driver
		              Connection connection= DriverManager.getConnection("jdbc:ucanaccess://C://Users//Administrator//eclipse-workspace//PProject//DatabaseLogin.accdb");//Establishing Connection
		              System.out.println("Connected Successfully");
					Pproject2 window = new Pproject2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					 System.out.println("Error in connection");
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	
	public Pproject2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 400, 629, 732);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("International Islamic University");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel.setBounds(210, 10, 318, 28);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Admission Form");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1.setBounds(279, 35, 136, 28);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel(" Candidate(Full Name)  :");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(23, 75, 157, 15);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Father Name :");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_3.setBounds(23, 114, 102, 15);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Father's ID  :");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_4.setBounds(291, 114, 90, 15);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("User Form No :");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_5.setBounds(23, 150, 76, 15);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Date of Birth :");
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_6.setBounds(23, 186, 97, 15);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Place of Birth :");
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_7.setBounds(179, 186, 76, 15);
		frame.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Year :");
		lblNewLabel_8.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_8.setBounds(380, 186, 54, 15);
		frame.getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Nationality :");
		lblNewLabel_9.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_9.setBounds(23, 211, 76, 15);
		frame.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Religion :");
		lblNewLabel_10.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_10.setBounds(178, 211, 54, 15);
		frame.getContentPane().add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("Sex :");
		lblNewLabel_11.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_11.setBounds(323, 211, 54, 15);
		frame.getContentPane().add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("Father's Occupation :");
		lblNewLabel_12.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_12.setBounds(23, 238, 112, 15);
		frame.getContentPane().add(lblNewLabel_12);
		
		JLabel lblNewLabel_13 = new JLabel("Income :");
		lblNewLabel_13.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_13.setBounds(261, 238, 54, 15);
		frame.getContentPane().add(lblNewLabel_13);
		
		JLabel lblNewLabel_14 = new JLabel("Address :");
		lblNewLabel_14.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_14.setBounds(23, 275, 54, 15);
		frame.getContentPane().add(lblNewLabel_14);
		
		JLabel lblNewLabel_15 = new JLabel("College :");
		lblNewLabel_15.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_15.setBounds(23, 310, 54, 15);
		frame.getContentPane().add(lblNewLabel_15);
		
		JLabel lblNewLabel_16 = new JLabel("Field :");
		lblNewLabel_16.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_16.setBounds(261, 310, 54, 15);
		frame.getContentPane().add(lblNewLabel_16);
		
		JLabel lblNewLabel_17 = new JLabel("Candidate Phone Number :");
		lblNewLabel_17.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_17.setBounds(10, 341, 136, 15);
		frame.getContentPane().add(lblNewLabel_17);
		
		JLabel lblNewLabel_18 = new JLabel("Email :");
		lblNewLabel_18.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_18.setBounds(248, 341, 54, 15);
		frame.getContentPane().add(lblNewLabel_18);
		
		JLabel lblNewLabel_19 = new JLabel("Father's Phone Number :");
		lblNewLabel_19.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_19.setBounds(10, 378, 136, 15);
		frame.getContentPane().add(lblNewLabel_19);
		
		JLabel lblNewLabel_20 = new JLabel("Ptcl no :");
		lblNewLabel_20.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_20.setBounds(23, 403, 54, 15);
		frame.getContentPane().add(lblNewLabel_20);
		
		JLabel lblNewLabel_21 = new JLabel("Qualification :");
		lblNewLabel_21.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_21.setBounds(10, 432, 97, 15);
		frame.getContentPane().add(lblNewLabel_21);
		
		table = new JTable();
		table.setFont(new Font("Times New Roman", Font.BOLD, 12));
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"Examination Passed", "Subjects", "Institution", "Board/University", "Year of passing", "Marks Obtained/Total Marks"},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column", "New column"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(116);
		table.getColumnModel().getColumn(1).setPreferredWidth(63);
		table.getColumnModel().getColumn(2).setPreferredWidth(78);
		table.getColumnModel().getColumn(3).setPreferredWidth(111);
		table.getColumnModel().getColumn(4).setPreferredWidth(97);
		table.getColumnModel().getColumn(5).setPreferredWidth(165);
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		table.setBounds(10, 457, 593, 15);
		frame.getContentPane().add(table);
		
		JLabel lblNewLabel_22 = new JLabel("Admission Test :");
		lblNewLabel_22.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_22.setBounds(10, 525, 125, 15);
		frame.getContentPane().add(lblNewLabel_22);
		
		table_1 = new JTable();
		table_1.setBounds(10, 612, 212, -54);
		frame.getContentPane().add(table_1);
		
		table_2 = new JTable();
		table_2.setFont(new Font("Times New Roman", Font.BOLD, 12));
		table_2.setModel(new DefaultTableModel(
			new Object[][] {
				{"Roll No.", "Name of Admission Test", "Provincial Region", "Conduction Authority", "Marks obt/total marks"},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column"
			}
		));
		table_2.getColumnModel().getColumn(1).setPreferredWidth(138);
		table_2.getColumnModel().getColumn(2).setPreferredWidth(110);
		table_2.getColumnModel().getColumn(3).setPreferredWidth(131);
		table_2.getColumnModel().getColumn(4).setPreferredWidth(141);
		table_2.setBorder(new LineBorder(new Color(0, 0, 0)));
		table_2.setBounds(10, 550, 593, 15);
		frame.getContentPane().add(table_2);
		
		JLabel lblNewLabel_23 = new JLabel("Date :");
		lblNewLabel_23.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_23.setBounds(23, 612, 54, 15);
		frame.getContentPane().add(lblNewLabel_23);
		
		JLabel lblNewLabel_24 = new JLabel("Signature of Applicant :");
		lblNewLabel_24.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_24.setBounds(380, 612, 136, 15);
		frame.getContentPane().add(lblNewLabel_24);
		
		textField = new JTextField();
		textField.setBounds(156, 73, 259, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(103, 111, 164, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(391, 111, 140, 21);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(113, 147, 264, 21);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(103, 180, 66, 21);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(261, 183, 90, 21);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(429, 180, 87, 21);
		frame.getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(102, 208, 66, 21);
		frame.getContentPane().add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setBounds(242, 208, 73, 21);
		frame.getContentPane().add(textField_8);
		textField_8.setColumns(10);
		
		textField_10 = new JTextField();
		textField_10.setBounds(152, 235, 66, 21);
		frame.getContentPane().add(textField_10);
		textField_10.setColumns(10);
		
		textField_11 = new JTextField();
		textField_11.setBounds(349, 235, 66, 21);
		frame.getContentPane().add(textField_11);
		textField_11.setColumns(10);
		
		textField_12 = new JTextField();
		textField_12.setBounds(87, 272, 280, 21);
		frame.getContentPane().add(textField_12);
		textField_12.setColumns(10);
		
		textField_13 = new JTextField();
		textField_13.setBounds(103, 307, 115, 21);
		frame.getContentPane().add(textField_13);
		textField_13.setColumns(10);
		
		textField_14 = new JTextField();
		textField_14.setBounds(318, 307, 116, 21);
		frame.getContentPane().add(textField_14);
		textField_14.setColumns(10);
		
		textField_15 = new JTextField();
		textField_15.setBounds(152, 338, 66, 21);
		frame.getContentPane().add(textField_15);
		textField_15.setColumns(10);
		
		textField_16 = new JTextField();
		textField_16.setBounds(291, 338, 143, 21);
		frame.getContentPane().add(textField_16);
		textField_16.setColumns(10);
		
		textField_17 = new JTextField();
		textField_17.setBounds(156, 375, 146, 21);
		frame.getContentPane().add(textField_17);
		textField_17.setColumns(10);
		
		textField_18 = new JTextField();
		textField_18.setBounds(156, 400, 146, 21);
		frame.getContentPane().add(textField_18);
		textField_18.setColumns(10);
		
		textField_19 = new JTextField();
		textField_19.setBounds(69, 612, 111, 21);
		frame.getContentPane().add(textField_19);
		textField_19.setColumns(10);
		
		textField_20 = new JTextField();
		textField_20.setBounds(516, 612, 66, 21);
		frame.getContentPane().add(textField_20);
		textField_20.setColumns(10);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//String DatabaseURL="jdbc:ucanaccess://C://Users//Administrator//eclipse-workspace//PProject//DatabaseLogin.accdb";
				try {
				//	String url="INSERT INTO   AdmissionForm(Name,FatherName,FatherID,UserID,DOB,POB,YearR,Nationaality,Religion,Sex,FOccupation,Income,Address,College,Field,UserPhno,Email,Fphno,Ptclno,Examination,Subjects,Institution,BoardOrUni,YOP,MarksQ,RollNo,AdmTest,Region,Authority,MarksAdm,DateE,Signature) Values('"+textField+"','"+textField_1+"','"+textField_2+"','"+textField_3+"','"+textField_4+"','"+textField_5+"','"+textField_6+"','"+textField_7+"','"+textField_8+"')";
					Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		              Connection connection= DriverManager.getConnection("jdbc:ucanaccess://C://Users//Administrator//eclipse-workspace//PProject//DatabaseLogin.accdb");
		              System.out.println("Connected Successfully");
		              //Crating PreparedStatement object
		              //PreparedStatement preparedStatement=connection.prepareStatement("insert into   AdmissionForm(Name )Values (?)");
		              PreparedStatement preparedStatement=connection.prepareStatement("insert into   AdmissionForm1(Name,FatherName,FatherID,UserID,DOB,POB,YearR,Nationality,Religion,Sex,FOccupation,Income,Address,College,Field,UserPhno,Ptclno,Examination,Subjects,Institution,BoardOrUni,YOP,MarksQ,RollNo,AdmTest,Region,Authority,MarksAdm,DateE,Signature) Values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		              //Setting values for Each Parameter
		              preparedStatement.setString(1,textField.getText());
		              preparedStatement.setString(2,textField_1.getText());
		              preparedStatement.setString(3,textField_2.getText());
		              preparedStatement.setString(4,textField_3.getText());
		              preparedStatement.setString(5,textField_4.getText());
		              preparedStatement.setString(6,textField_5.getText());
		              preparedStatement.setString(7,textField_6.getText());
		              preparedStatement.setString(8,textField_7.getText());
		              preparedStatement.setString(9,textField_8.getText());
		              preparedStatement.setString(10,(String) comboBox.getSelectedItem());
		              preparedStatement.setString(11,textField_10.getText());
		              preparedStatement.setString(12,textField_11.getText());
		              preparedStatement.setString(13,textField_12.getText());
		              preparedStatement.setString(14,textField_13.getText());
		              preparedStatement.setString(15,textField_14.getText());
		              preparedStatement.setString(16,textField_15.getText());
		              //preparedStatement.setString(17,textField_16.getText());
		              //preparedStatement.setString(18,textField_17.getText());
		              preparedStatement.setString(17,textField_18.getText());
		              
		              preparedStatement.setString(18,textField_9.getText());
		              preparedStatement.setString(19,textField_22.getText());
		              preparedStatement.setString(20,textField_24.getText());
		              preparedStatement.setString(21,textField_26.getText());
		              preparedStatement.setString(22,textField_28.getText());
		              preparedStatement.setString(23,textField_30.getText());
		              preparedStatement.setString(24,textField_32.getText());
		              preparedStatement.setString(25,textField_33.getText());
		              preparedStatement.setString(26,textField_34.getText());
		              preparedStatement.setString(27,textField_35.getText());
		              preparedStatement.setString(28,textField_36.getText());
		              preparedStatement.setString(29,textField_19.getText());
		              preparedStatement.setString(30,textField_20.getText());
		            //  preparedStatement.setString(2,"Ranchi");
		              //Executing Query
		              preparedStatement.executeUpdate();
		              System.out.println("data inserted successfully");
		              JOptionPane.showMessageDialog(null, 
		                        "Welcome New User", 
		                        "TITLE", 
		                        JOptionPane.WARNING_MESSAGE);
					}catch(SQLException | ClassNotFoundException ex) {
					ex.printStackTrace();	}
			}
			
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton.setBounds(322, 648, 93, 36);
		frame.getContentPane().add(btnNewButton);
		
		textField_9 = new JTextField();
		textField_9.setBounds(10, 475, 102, 21);
		frame.getContentPane().add(textField_9);
		textField_9.setColumns(10);
		
		textField_22 = new JTextField();
		textField_22.setBounds(118, 475, 60, 21);
		frame.getContentPane().add(textField_22);
		textField_22.setColumns(10);
		
		textField_24 = new JTextField();
		textField_24.setBounds(179, 475, 76, 21);
		frame.getContentPane().add(textField_24);
		textField_24.setColumns(10);
		
		textField_26 = new JTextField();
		textField_26.setBounds(261, 475, 90, 21);
		frame.getContentPane().add(textField_26);
		textField_26.setColumns(10);
		
		textField_28 = new JTextField();
		textField_28.setBounds(356, 475, 90, 21);
		frame.getContentPane().add(textField_28);
		textField_28.setColumns(10);
		
		textField_30 = new JTextField();
		textField_30.setBounds(450, 475, 153, 21);
		frame.getContentPane().add(textField_30);
		textField_30.setColumns(10);
		
		textField_32 = new JTextField();
		textField_32.setBounds(11, 568, 66, 21);
		frame.getContentPane().add(textField_32);
		textField_32.setColumns(10);
		
		textField_33 = new JTextField();
		textField_33.setBounds(87, 568, 125, 21);
		frame.getContentPane().add(textField_33);
		textField_33.setColumns(10);
		
		textField_34 = new JTextField();
		textField_34.setBounds(225, 568, 102, 21);
		frame.getContentPane().add(textField_34);
		textField_34.setColumns(10);
		
		textField_35 = new JTextField();
		textField_35.setBounds(337, 568, 109, 21);
		frame.getContentPane().add(textField_35);
		textField_35.setColumns(10);
		
		textField_36 = new JTextField();
		textField_36.setBounds(467, 568, 136, 21);
		frame.getContentPane().add(textField_36);
		textField_36.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Exit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 int result = JOptionPane.showConfirmDialog(frame,"Sure? You want to fill another Form?", "Swing Tester",
	                      JOptionPane.YES_NO_OPTION,
	                      JOptionPane.QUESTION_MESSAGE);
	                   if(result == JOptionPane.YES_OPTION){
	                	   Pproject2 f = new Pproject2();
		       	            f. AdmForm();
		       	            
	                	   
	                	  
	                   }else if (result == JOptionPane.NO_OPTION){
	                	   LoginSuccessfull f = new LoginSuccessfull();
		   		            f. Window2();
	                   }else {
	                	   
	                   }
				
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 13));
		btnNewButton_1.setBounds(119, 649, 93, 36);
		frame.getContentPane().add(btnNewButton_1);
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female", "Other"}));
		comboBox.setBounds(349, 207, 78, 23);
		frame.getContentPane().add(comboBox);
	}
}
