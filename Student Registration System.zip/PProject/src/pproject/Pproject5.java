package pproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;

import net.proteanit.sql.DbUtils;

import javax.swing.JComboBox;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class Pproject5 {

	private JFrame frame;
	private JButton btnBack;
	private JTabbedPane table;
	private JComboBox comboBox_1;
	private JTextField textField;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JComboBox comboBox_2;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void Searchh() {
		DefaultTableModel dtm;
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			        Connection connection= DriverManager.getConnection("jdbc:ucanaccess://C://Users//Administrator//eclipse-workspace//PProject//DatabaseLogin.accdb");
			        System.out.println("Connected Successfully");
					Pproject5 window = new Pproject5();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Pproject5() {
		initialize();
	}
    public void fillcombo1() {
    	try {
    		Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection connection= DriverManager.getConnection("jdbc:ucanaccess://C://Users//Administrator//eclipse-workspace//PProject//DatabaseLogin.accdb");
            System.out.println("Connected Successfully");
    		String query = "select * from AdmissionForm1";
			PreparedStatement pst = connection.prepareStatement(query);
    		ResultSet rs= pst.executeQuery();
    		while(rs.next()) {
    			comboBox_1.addItem(rs.getString("UserID"));
    		}
    	}catch(Exception a) {
    		a.printStackTrace();
    	}
    }
    public void fillcombo2() {
    	try {
    		Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection connection= DriverManager.getConnection("jdbc:ucanaccess://C://Users//Administrator//eclipse-workspace//PProject//DatabaseLogin.accdb");
            System.out.println("Connected Successfully");
    		String query = "select * from AdmissionForm1";
			PreparedStatement pst = connection.prepareStatement(query);
    		ResultSet rs= pst.executeQuery();
    		while(rs.next()) {
    			comboBox_2.addItem(rs.getString("Name"));
    		}
    	}catch(Exception a) {
    		a.printStackTrace();
    	}
    }
    public void fillcombo() {
    	try {
    		Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection connection= DriverManager.getConnection("jdbc:ucanaccess://C://Users//Administrator//eclipse-workspace//PProject//DatabaseLogin.accdb");
            System.out.println("Connected Successfully");
    		String query = "select * from AdmissionForm1";
			PreparedStatement pst = connection.prepareStatement(query);
    		ResultSet rs= pst.executeQuery();
    		while(rs.next()) {
    			comboBox.addItem(rs.getString("RollNo"));
    		}
    	}catch(Exception a) {
    		a.printStackTrace();
    	}
    }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 575, 355);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Search User");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel.setBounds(147, 20, 106, 20);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Candidate ID :");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(42, 67, 85, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("RollNo :");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_2.setBounds(42, 136, 68, 15);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Name :");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_3.setBounds(42, 102, 54, 15);
		frame.getContentPane().add(lblNewLabel_3);
		
		btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginSuccessfull f = new LoginSuccessfull();
	            f. Window2();
			}
		});
		btnBack.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnBack.setBounds(195, 174, 93, 23);
		frame.getContentPane().add(btnBack);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 208, 483, 20);
		frame.getContentPane().add(panel);
		
		JLabel lblNewLabel_4 = new JLabel("Table From Database");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		panel.add(lblNewLabel_4);
		
		comboBox_1 = new JComboBox();
		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		              Connection connection= DriverManager.getConnection("jdbc:ucanaccess://C://Users//Administrator//eclipse-workspace//PProject//DatabaseLogin.accdb");
		              System.out.println("Connected Successfully");
					String query = "select * from AdmissionForm1 where UserID= ?";
					PreparedStatement pstt=connection.prepareStatement(query);
					pstt.setString(1,(String) comboBox_1.getSelectedItem());
					ResultSet rs= pstt.executeQuery();
					while(rs.next()) {
						textField.setText(rs.getString("Name"));
						textField_3.setText(rs.getString("FatherName"));
						textField_4.setText(rs.getString("UserPhno"));
						textField_5.setText(rs.getString("Examination"));
						textField_6.setText(rs.getString("MarksQ"));
						textField_7.setText(rs.getString("RollNo"));
					}
					pstt.close();
				}catch(Exception b) {
					b.printStackTrace();
				}
			}
		});
		comboBox_1.setBounds(179, 63, 137, 23);
		frame.getContentPane().add(comboBox_1);
		fillcombo1();
		
		JLabel lblNewLabel_5 = new JLabel("Phno#");
		lblNewLabel_5.setBounds(167, 238, 54, 15);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Name");
		lblNewLabel_6.setBounds(20, 238, 54, 15);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Father Name");
		lblNewLabel_7.setBounds(84, 238, 73, 15);
		frame.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_9 = new JLabel("Exam Marks");
		lblNewLabel_9.setBounds(243, 238, 64, 15);
		frame.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Test Marks");
		lblNewLabel_10.setBounds(334, 238, 62, 15);
		frame.getContentPane().add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("Roll No");
		lblNewLabel_11.setBounds(406, 238, 54, 15);
		frame.getContentPane().add(lblNewLabel_11);
		
		textField = new JTextField();
		textField.setBounds(8, 254, 66, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(82, 254, 66, 21);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(159, 254, 74, 21);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(243, 254, 81, 21);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(334, 254, 68, 21);
		frame.getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(406, 254, 87, 21);
		frame.getContentPane().add(textField_7);
		textField_7.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("fill comboBox to search");
		lblNewLabel_8.setFont(new Font("SimSun", Font.BOLD, 12));
		lblNewLabel_8.setForeground(Color.BLUE);
		lblNewLabel_8.setBounds(243, 24, 174, 15);
		frame.getContentPane().add(lblNewLabel_8);
		
		 comboBox_2 = new JComboBox();
		comboBox_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		              Connection connection= DriverManager.getConnection("jdbc:ucanaccess://C://Users//Administrator//eclipse-workspace//PProject//DatabaseLogin.accdb");
		              System.out.println("Connected Successfully");
					String query = "select * from AdmissionForm1 where Name= ?";
					PreparedStatement pstt=connection.prepareStatement(query);
					pstt.setString(1,(String) comboBox_2.getSelectedItem());
					ResultSet rs= pstt.executeQuery();
					while(rs.next()) {
						textField.setText(rs.getString("Name"));
						textField_3.setText(rs.getString("FatherName"));
						textField_4.setText(rs.getString("UserPhno"));
						textField_5.setText(rs.getString("Examination"));
						textField_6.setText(rs.getString("MarksQ"));
						textField_7.setText(rs.getString("RollNo"));
					}
					pstt.close();
				}catch(Exception b) {
					b.printStackTrace();
				}
				
				
			}
		});
		comboBox_2.setBounds(179, 98, 137, 23);
		frame.getContentPane().add(comboBox_2);
		fillcombo2();
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		              Connection connection= DriverManager.getConnection("jdbc:ucanaccess://C://Users//Administrator//eclipse-workspace//PProject//DatabaseLogin.accdb");
		              System.out.println("Connected Successfully");
					String query = "select * from AdmissionForm1 where RollNo= ?";
					PreparedStatement pstt=connection.prepareStatement(query);
					pstt.setString(1,(String) comboBox.getSelectedItem());
					ResultSet rs= pstt.executeQuery();
					while(rs.next()) {
						textField.setText(rs.getString("Name"));
						textField_3.setText(rs.getString("FatherName"));
						textField_4.setText(rs.getString("UserPhno"));
						textField_5.setText(rs.getString("Examination"));
						textField_6.setText(rs.getString("MarksQ"));
						textField_7.setText(rs.getString("RollNo"));
					}
					pstt.close();
				}catch(Exception b) {
					b.printStackTrace();
				}
				
				
			}
		});
		comboBox.setBounds(179, 132, 137, 23);
		frame.getContentPane().add(comboBox);
		fillcombo();
	}
}
